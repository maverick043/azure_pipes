#!/usr/bin/env python3
"""Seed and download Docling models into the shared model volume.

Runs as an init container (same image as docling-serve). Several pods can run
it at the same time against one volume: a file lock serialises them and a
marker file records which model set is already present, so restarts and new
replicas start immediately once the first pod has finished.
"""

import errno
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

DEFAULT_IMAGE_MODELS = "/opt/app-root/src/.cache/docling/models"


def log(msg: str) -> None:
    print(f"[fetch-models] {msg}", flush=True)


def flag(name: str) -> bool:
    return os.environ.get(name, "false").strip().lower() in ("1", "true", "yes")


MODELS_DIR = os.environ["MODELS_DIR"]
MODELS = os.environ.get("MODELS_LIST", "").split()
EXTRA_ARGS = json.loads(os.environ.get("MODELS_EXTRA_ARGS") or "[]")
DOWNLOAD = flag("MODELS_DOWNLOAD")
SEED = flag("MODELS_SEED_FROM_IMAGE")
FORCE = flag("MODELS_FORCE")
# The image bakes the default models here (ENV DOCLING_SERVE_ARTIFACTS_PATH in
# the upstream Containerfile); the init container does not override it.
IMAGE_MODELS = (
    os.environ.get("IMAGE_MODELS_DIR")
    or os.environ.get("DOCLING_SERVE_ARTIFACTS_PATH")
    or DEFAULT_IMAGE_MODELS
)

SPEC = {
    "models": sorted(MODELS) if DOWNLOAD else [],
    "extra_args": EXTRA_ARGS if DOWNLOAD else [],
    "seed_from_image": SEED,
}
DIGEST = hashlib.sha256(json.dumps(SPEC, sort_keys=True).encode()).hexdigest()
MARKER = os.path.join(MODELS_DIR, ".docling-helm-models.json")
LOCK = os.path.join(MODELS_DIR, ".docling-helm-models.lock")


def read_marker():
    try:
        with open(MARKER) as fh:
            return json.load(fh).get("digest")
    except (OSError, ValueError):
        return None


def write_marker() -> None:
    tmp = MARKER + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(
            {
                "digest": DIGEST,
                "spec": SPEC,
                "updated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            },
            fh,
            indent=2,
        )
    os.replace(tmp, MARKER)


def seed_from_image() -> None:
    if not os.path.isdir(IMAGE_MODELS):
        log(f"no baked models at {IMAGE_MODELS}; skipping seed")
        return
    if os.path.realpath(IMAGE_MODELS) == os.path.realpath(MODELS_DIR):
        return
    copied = skipped = 0
    for root, _dirs, files in os.walk(IMAGE_MODELS):
        rel = os.path.relpath(root, IMAGE_MODELS)
        dst_root = os.path.normpath(os.path.join(MODELS_DIR, rel))
        os.makedirs(dst_root, exist_ok=True)
        for name in files:
            src = os.path.join(root, name)
            dst = os.path.join(dst_root, name)
            if os.path.exists(dst) and os.path.getsize(dst) == os.path.getsize(src):
                skipped += 1
                continue
            shutil.copyfile(src, dst + ".part")
            os.replace(dst + ".part", dst)
            copied += 1
    log(f"seeded from image {IMAGE_MODELS}: {copied} copied, {skipped} already present")


def download() -> int:
    cmd = ["docling-tools", "models", "download", "--output-dir", MODELS_DIR]
    if FORCE:
        cmd.append("--force")
    cmd += MODELS + EXTRA_ARGS
    for attempt in range(1, 4):
        log(f"attempt {attempt}: {' '.join(cmd)}")
        rc = subprocess.call(cmd)
        if rc == 0:
            return 0
        log(f"download failed with exit code {rc}")
        time.sleep(15 * attempt)
    return rc


def main() -> int:
    os.makedirs(MODELS_DIR, exist_ok=True)
    with open(LOCK, "a+") as lock:
        log("waiting for volume lock")
        try:
            fcntl.flock(lock, fcntl.LOCK_EX)
        except OSError as exc:  # some network filesystems lack lock support
            if exc.errno not in (errno.ENOLCK, errno.EOPNOTSUPP, errno.ENOSYS):
                raise
            log(f"file locking unsupported ({exc}); continuing without lock")

        if read_marker() == DIGEST and not FORCE:
            log(f"model set already present in {MODELS_DIR}; nothing to do")
            return 0

        if SEED:
            seed_from_image()
        if DOWNLOAD and MODELS:
            rc = download()
            if rc != 0:
                return rc
        write_marker()
        log(f"models ready in {MODELS_DIR}: {', '.join(SPEC['models']) or 'image defaults'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
