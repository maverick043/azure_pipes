{{/* vim: set filetype=mustache: */}}

{{- define "docling-serve.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "docling-serve.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "docling-serve.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "docling-serve.labels" -}}
helm.sh/chart: {{ include "docling-serve.chart" . }}
{{ include "docling-serve.selectorLabels" . }}
app.kubernetes.io/version: {{ include "docling-serve.imageTag" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: docling-serve
{{- end }}

{{- define "docling-serve.selectorLabels" -}}
app.kubernetes.io/name: {{ include "docling-serve.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/* Component-specific selector labels: pass (dict "ctx" $ "component" "api") */}}
{{- define "docling-serve.componentSelectorLabels" -}}
{{ include "docling-serve.selectorLabels" .ctx }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{- define "docling-serve.componentLabels" -}}
{{ include "docling-serve.labels" .ctx }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{- define "docling-serve.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "docling-serve.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "docling-serve.imageTag" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end }}

{{- define "docling-serve.image" -}}
{{- printf "%s:%s" .Values.image.repository (include "docling-serve.imageTag" .) }}
{{- end }}

{{- define "docling-serve.secretName" -}}
{{- include "docling-serve.fullname" . }}
{{- end }}

{{- define "docling-serve.redisFullname" -}}
{{- printf "%s-redis" (include "docling-serve.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "docling-serve.workerFullname" -}}
{{- printf "%s-worker" (include "docling-serve.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* ---------------------------------------------------------------- engine */}}

{{- define "docling-serve.isRQ" -}}
{{- if eq .Values.engine.kind "rq" }}true{{- end }}
{{- end }}

{{- define "docling-serve.useBuiltinRedis" -}}
{{- if and (include "docling-serve.isRQ" .) .Values.redis.enabled }}true{{- end }}
{{- end }}

{{/* ---------------------------------------------------------------- models */}}

{{/* True when a model volume is mounted (PVC or emptyDir). */}}
{{- define "docling-serve.modelsVolumeEnabled" -}}
{{- if or .Values.models.persistence.enabled .Values.models.download.enabled }}true{{- end }}
{{- end }}

{{- define "docling-serve.modelsClaimName" -}}
{{- if .Values.models.persistence.existingClaim }}
{{- .Values.models.persistence.existingClaim }}
{{- else }}
{{- printf "%s-models" (include "docling-serve.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/* True when the model volume is a PVC limited to a single node. */}}
{{- define "docling-serve.modelsRWO" -}}
{{- if and .Values.models.persistence.enabled (not (has "ReadWriteMany" .Values.models.persistence.accessModes)) (not .Values.models.persistence.existingClaim) }}true{{- end }}
{{- end }}

{{/* Pod volume for models */}}
{{- define "docling-serve.modelsVolume" -}}
- name: models
{{- if .Values.models.persistence.enabled }}
  persistentVolumeClaim:
    claimName: {{ include "docling-serve.modelsClaimName" . }}
{{- else }}
  emptyDir:
    sizeLimit: {{ .Values.models.emptyDirSizeLimit }}
{{- end }}
{{- end }}

{{/* True when the fetch-models init container must run. */}}
{{- define "docling-serve.modelsInitEnabled" -}}
{{- if and (include "docling-serve.modelsVolumeEnabled" .) (or .Values.models.download.enabled .Values.models.seedFromImage) }}true{{- end }}
{{- end }}

{{/* API pods load models only with the local engine (RQ workers do the work). */}}
{{- define "docling-serve.apiMountsModels" -}}
{{- if and (not (include "docling-serve.isRQ" .)) (include "docling-serve.modelsVolumeEnabled" .) }}true{{- end }}
{{- end }}

{{/* Volumes shared by API and worker pods. Pass (dict "ctx" $ "models" bool) */}}
{{- define "docling-serve.podVolumes" -}}
{{- $ctx := .ctx }}
- name: tmp
  emptyDir: {}
- name: scratch
  emptyDir:
    sizeLimit: {{ $ctx.Values.scratch.sizeLimit }}
{{- if $ctx.Values.scratch.shmSizeLimit }}
- name: dshm
  emptyDir:
    medium: Memory
    sizeLimit: {{ $ctx.Values.scratch.shmSizeLimit }}
{{- end }}
{{- if $ctx.Values.docling.config }}
- name: config
  configMap:
    name: {{ include "docling-serve.fullname" $ctx }}
    items:
      - key: config.yaml
        path: config.yaml
{{- end }}
{{- if .models }}
{{ include "docling-serve.modelsVolume" $ctx }}
{{- if include "docling-serve.modelsInitEnabled" $ctx }}
- name: scripts
  configMap:
    name: {{ printf "%s-scripts" (include "docling-serve.fullname" $ctx) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Volume mounts shared by API and worker containers. Pass (dict "ctx" $ "models" bool) */}}
{{- define "docling-serve.podVolumeMounts" -}}
{{- $ctx := .ctx }}
- name: tmp
  mountPath: /tmp
- name: scratch
  mountPath: /scratch
{{- if $ctx.Values.scratch.shmSizeLimit }}
- name: dshm
  mountPath: /dev/shm
{{- end }}
{{- if $ctx.Values.docling.config }}
- name: config
  mountPath: /etc/docling-serve
  readOnly: true
{{- end }}
{{- if .models }}
- name: models
  mountPath: {{ $ctx.Values.models.path }}
{{- end }}
{{- end }}

{{/* Init container that seeds/downloads models into the volume */}}
{{- define "docling-serve.modelsInitContainer" -}}
- name: fetch-models
  image: {{ include "docling-serve.image" . }}
  imagePullPolicy: {{ .Values.image.pullPolicy }}
  command: ["python3", "/scripts/fetch-models.py"]
  env:
    - name: MODELS_DIR
      value: {{ .Values.models.path | quote }}
    - name: MODELS_LIST
      value: {{ join " " .Values.models.download.list | quote }}
    - name: MODELS_EXTRA_ARGS
      value: {{ .Values.models.download.extraArgs | toJson | quote }}
    - name: MODELS_DOWNLOAD
      value: {{ .Values.models.download.enabled | quote }}
    - name: MODELS_SEED_FROM_IMAGE
      value: {{ .Values.models.seedFromImage | quote }}
    - name: MODELS_FORCE
      value: {{ .Values.models.download.force | quote }}
    - name: HF_HUB_DOWNLOAD_TIMEOUT
      value: "90"
    - name: HF_HUB_ETAG_TIMEOUT
      value: "90"
    - name: HF_HUB_DISABLE_TELEMETRY
      value: "1"
    {{- with .Values.models.download.env }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- with .Values.models.download.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.securityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  volumeMounts:
    - name: models
      mountPath: {{ .Values.models.path }}
    - name: scripts
      mountPath: /scripts
      readOnly: true
    - name: tmp
      mountPath: /tmp
{{- end }}

{{/* ------------------------------------------------------------- strategy */}}

{{/* Usage: include "docling-serve.strategy" (dict "ctx" $ "strategy" .Values.api.strategy "mountsModels" true) */}}
{{- define "docling-serve.strategy" -}}
{{- if .strategy }}
strategy:
  {{- toYaml .strategy | nindent 2 }}
{{- else if and .mountsModels (include "docling-serve.modelsRWO" .ctx) }}
strategy:
  type: Recreate
{{- end }}
{{- end }}

{{/* ------------------------------------------------------------------ env */}}

{{/* Environment shared by API pods and RQ workers. */}}
{{- define "docling-serve.commonEnv" -}}
{{- if .Values.cpu.forceCpu }}
- name: DOCLING_DEVICE
  value: cpu
- name: CUDA_VISIBLE_DEVICES
  value: ""
{{- end }}
- name: DOCLING_NUM_THREADS
  value: {{ .Values.cpu.numThreads | quote }}
- name: OMP_NUM_THREADS
  value: {{ .Values.cpu.numThreads | quote }}
- name: DOCLING_PERF_PAGE_BATCH_SIZE
  value: {{ .Values.cpu.pageBatchSize | quote }}
- name: DOCLING_PERF_ELEMENTS_BATCH_SIZE
  value: {{ .Values.cpu.elementsBatchSize | quote }}
- name: DOCLING_SERVE_LOG_LEVEL
  value: {{ .Values.docling.logLevel | quote }}
- name: DOCLING_SERVE_LOG_FORMAT
  value: {{ .Values.docling.logFormat | quote }}
- name: DOCLING_SERVE_ENABLE_REMOTE_SERVICES
  value: {{ .Values.docling.enableRemoteServices | quote }}
- name: DOCLING_SERVE_OPTIONS_CACHE_SIZE
  value: {{ .Values.docling.optionsCacheSize | quote }}
{{- with .Values.docling.maxNumPages }}
- name: DOCLING_SERVE_MAX_NUM_PAGES
  value: {{ . | quote }}
{{- end }}
{{- with .Values.docling.maxFileSize }}
- name: DOCLING_SERVE_MAX_FILE_SIZE
  value: {{ . | quote }}
{{- end }}
{{- with .Values.docling.maxDocumentTimeout }}
- name: DOCLING_SERVE_MAX_DOCUMENT_TIMEOUT
  value: {{ . | quote }}
{{- end }}
{{- with .Values.docling.defaultVlmPreset }}
- name: DOCLING_SERVE_DEFAULT_VLM_PRESET
  value: {{ . | quote }}
{{- end }}
{{- with .Values.docling.defaultPictureDescriptionPreset }}
- name: DOCLING_SERVE_DEFAULT_PICTURE_DESCRIPTION_PRESET
  value: {{ . | quote }}
{{- end }}
{{- if .Values.docling.config }}
- name: DOCLING_SERVE_CONFIG_FILE
  value: /etc/docling-serve/config.yaml
{{- end }}
- name: DOCLING_SERVE_ENG_KIND
  value: {{ .Values.engine.kind | quote }}
{{- if include "docling-serve.isRQ" . }}
{{- include "docling-serve.redisEnv" . }}
- name: DOCLING_SERVE_ENG_RQ_QUEUE_NAME
  value: {{ .Values.engine.rq.queueName | quote }}
- name: DOCLING_SERVE_ENG_RQ_RESULTS_TTL
  value: {{ .Values.engine.rq.resultsTtl | quote }}
- name: DOCLING_SERVE_ENG_RQ_REDIS_MAX_CONNECTIONS
  value: {{ .Values.engine.rq.redisMaxConnections | quote }}
{{- end }}
{{- with .Values.otel.endpoint }}
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: {{ . | quote }}
- name: DOCLING_SERVE_OTEL_ENABLE_TRACES
  value: "true"
{{- end }}
{{- end }}

{{/* Redis URL env for the RQ engine. */}}
{{- define "docling-serve.redisEnv" -}}
{{- if include "docling-serve.useBuiltinRedis" . }}
- name: REDIS_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.redis.auth.existingSecret | default (include "docling-serve.secretName" .) }}
      key: {{ if .Values.redis.auth.existingSecret }}{{ .Values.redis.auth.existingSecretKey }}{{ else }}redis-password{{ end }}
- name: DOCLING_SERVE_ENG_RQ_REDIS_URL
  value: {{ printf "redis://:$(REDIS_PASSWORD)@%s:6379/0" (include "docling-serve.redisFullname" .) | quote }}
{{- else }}
- name: DOCLING_SERVE_ENG_RQ_REDIS_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.externalRedis.existingSecret | default (include "docling-serve.secretName" .) }}
      key: {{ if .Values.externalRedis.existingSecret }}{{ .Values.externalRedis.existingSecretKey }}{{ else }}redis-url{{ end }}
{{- end }}
{{- end }}

{{/* ----------------------------------------------------------- validation */}}

{{- define "docling-serve.validate" -}}
{{- if not (has .Values.engine.kind (list "local" "rq")) }}
{{- fail (printf "engine.kind must be \"local\" or \"rq\" (got %q). The Ray engine needs an external Ray cluster and is not templated by this chart; set DOCLING_SERVE_ENG_KIND via extraEnv if you run one." .Values.engine.kind) }}
{{- end }}
{{- if and (include "docling-serve.isRQ" .) (not .Values.redis.enabled) (not .Values.externalRedis.url) (not .Values.externalRedis.existingSecret) }}
{{- fail "engine.kind=rq needs Redis: keep redis.enabled=true or set externalRedis.url / externalRedis.existingSecret" }}
{{- end }}
{{- if and .Values.models.download.enabled (empty .Values.models.download.list) }}
{{- fail "models.download.enabled=true but models.download.list is empty" }}
{{- end }}
{{- end }}
