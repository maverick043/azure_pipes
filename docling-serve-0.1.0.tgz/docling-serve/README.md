# docling-serve Helm chart (CPU-only)

Runs [Docling Serve](https://github.com/docling-project/docling-serve) on Kubernetes with every model on CPU: no GPU, no VRAM, no NVIDIA/ROCm runtime.

It is derived from the upstream compose files (`docs/deploy-examples/compose-*.yaml`) and Kubernetes examples, with these changes:

| Upstream compose | This chart |
|---|---|
| `docling-serve-cu126` image + `runtime: nvidia` | `ghcr.io/docling-project/docling-serve-cpu` (CPU-only torch), pinned to `v1.36.0` |
| GPU auto-selected | `DOCLING_DEVICE=cpu`, `CUDA_VISIBLE_DEVICES=""`, thread counts set from values |
| Models baked into the image only | Persistent model cache (PVC) seeded from the image + `docling-tools models download` init container |
| Single container | Optional RQ engine: API + horizontally scalable CPU workers + Redis |
| Port 5001, `DOCLING_SERVE_ENABLE_UI=true` | Same, plus Service/Ingress, probes, HPA, PDB, ServiceMonitor, API key |

## Install

```sh
helm install docling ./docling-serve -n docling --create-namespace
kubectl -n docling logs -f deploy/docling-docling-serve -c fetch-models   # first start downloads models
kubectl -n docling port-forward svc/docling-docling-serve 5001:5001
open http://localhost:5001/ui
```

Test a conversion:

```sh
curl -X POST http://localhost:5001/v1/convert/source \
  -H "Content-Type: application/json" \
  -d '{"sources": [{"kind": "http", "url": "https://arxiv.org/pdf/2501.17887"}]}'
```

## Models served on CPU

The init container prepares these models in the PVC (`models.download.list`):

| Model (download name) | Used for | Request option |
|---|---|---|
| `layout`, `tableformer` | Standard PDF pipeline | default |
| `rapidocr`, `easyocr` | OCR | `ocr_preset` / `do_ocr` |
| `picture_classifier` | Picture classification | `do_picture_classification` |
| `code_formula` | Code & formula enrichment | `do_code_enrichment`, `do_formula_enrichment` |
| `smolvlm` | Picture descriptions (SmolVLM-256M) | `do_picture_description: true`, `picture_description_preset: smolvlm` |
| `granitedocling` | End-to-end VLM pipeline (granite-docling-258M) | `pipeline: vlm`, `vlm_pipeline_preset: granite_docling` |

Add more (e.g. `granite_vision`, `granite_chart_extraction_v4`, `smoldocling`) to the list. Larger VLMs work on CPU but are slow; raise memory limits accordingly (~8Gi for `granite_vision`).

How the cache works:

1. `models.seedFromImage` copies the models already baked into the image onto the volume (no network).
2. `docling-tools models download --output-dir /models <list>` fetches the rest.
3. A marker file records the list; restarts and extra replicas skip the download. Changing the list re-runs it. A file lock prevents two pods from downloading at once.
4. Docling reads them through `DOCLING_SERVE_ARTIFACTS_PATH=/models`. Docling Serve never downloads models at request time, so a model missing from the list fails the request instead of silently calling out.

Proxy or gated models: `models.download.env` (e.g. `HTTPS_PROXY`, `HF_TOKEN` from a secret, `HF_ENDPOINT` for a mirror). The PVC is kept on `helm uninstall` (`models.persistence.keep`).

## CPU tuning

Torch uses `cpu.numThreads` threads per conversion worker. Keep

```
cpu.numThreads × engine.local.numWorkers ≈ api.resources.limits.cpu     (local engine)
cpu.numThreads ≈ worker.resources.limits.cpu                             (RQ engine)
```

Defaults: 4 CPU limit, 2 workers × 2 threads. For big single documents, prefer fewer workers with more threads; for many small documents, more workers. `engine.local.shareModels=true` saves RAM when running several workers. Conversions on CPU are slower than on GPU, so `docling.maxSyncWait` is raised to 600s; use the `/v1/convert/source/async` endpoints for long documents.

## Scaling

**Local engine (default)** — conversions run in the API pods. Async task state lives in the pod that accepted the task, so with more than one replica the Service switches to `ClientIP` affinity automatically; behind an Ingress add cookie affinity (example in `values.yaml`).

**RQ engine** — the API enqueues jobs in Redis and a worker Deployment converts them. Scale workers by replicas or HPA. Only workers mount the model volume.

```sh
helm install docling ./docling-serve -f ci/rq-values.yaml
```

Several pods mounting the model PVC on different nodes need a `ReadWriteMany` StorageClass (NFS, CephFS, EFS, Azure Files ...). With `ReadWriteOnce` the chart switches to the `Recreate` strategy and NOTES warns when several pods would need the volume. Alternatively set `models.persistence.enabled=false` so every pod fills its own emptyDir.

## Common setups

| Scenario | Values |
|---|---|
| Single node, defaults | — |
| Several API replicas, shared models | `ci/local-multi-replica-values.yaml` |
| API + CPU workers, built-in Redis, Ingress, API key, metrics | `ci/rq-values.yaml` |
| Existing Redis, per-pod model cache | `ci/external-redis-values.yaml` |
| Air-gapped, image-baked models only | `ci/image-models-values.yaml` |

API key: `docling.apiKey.value` (stored in a Secret) or `docling.apiKey.existingSecret`. Clients send `X-Api-Key`. Health endpoints stay open for probes.

Any setting from the upstream [configuration reference](https://github.com/docling-project/docling-serve/blob/main/docs/configuration.md) can go in `docling.config` (written to a config file) or `extraEnv`.

OpenShift (restricted SCC): set `podSecurityContext.runAsUser=null` and `podSecurityContext.fsGroup=null`.

## Key values

| Key | Default | Description |
|---|---|---|
| `image.repository` | `ghcr.io/docling-project/docling-serve-cpu` | CPU-only image (also on quay.io) |
| `image.tag` | appVersion (`v1.36.0`) | |
| `cpu.forceCpu` | `true` | `DOCLING_DEVICE=cpu`, hide GPUs |
| `cpu.numThreads` | `2` | torch/OMP threads per worker |
| `engine.kind` | `local` | `local` or `rq` |
| `engine.local.numWorkers` | `2` | conversion threads per API pod |
| `models.download.list` | see above | models fetched into the cache |
| `models.persistence.enabled` | `true` | PVC (`10Gi`, RWO) vs emptyDir |
| `models.persistence.accessModes` | `[ReadWriteOnce]` | use `ReadWriteMany` for multi-node |
| `api.replicaCount` | `1` | |
| `api.resources` | 2–4 CPU, 4–8Gi | |
| `api.autoscaling.enabled` | `false` | CPU-based HPA |
| `worker.replicaCount` | `2` | RQ workers |
| `redis.enabled` | `true` | built-in Redis when `engine.kind=rq` |
| `externalRedis.url` | `""` | use with `redis.enabled=false` |
| `docling.enableUI` | `true` | `/ui` |
| `docling.apiKey.value` | `""` | require `X-Api-Key` |
| `docling.maxSyncWait` | `600` | seconds for sync endpoints |
| `docling.config` | `{}` | extra settings as a config file |
| `ingress.enabled` | `false` | |
| `metrics.serviceMonitor.enabled` | `false` | scrapes `/metrics` |

See `values.yaml` for everything, with comments. `values.schema.json` validates values on install.

## Development

```sh
helm lint . && helm template t . -f ci/rq-values.yaml | kubeconform -strict -skip ServiceMonitor
helm unittest -f 'unittests/*_test.yaml' .
```
